# from enum import StrEnum


# class RoleCode(StrEnum):
#     CITIZEN = "CITIZEN"
#     NAGAR_SEVAK = "NAGAR_SEVAK"
#     OFFICER = "OFFICER"
#     ENGINEER = "ENGINEER"
#     CONTRACTOR = "CONTRACTOR"
#     ADMIN = "ADMIN"


# class PermissionAction(StrEnum):
#     VIEW = "VIEW"
#     CREATE = "CREATE"
#     EDIT = "EDIT"
#     DELETE = "DELETE"
#     UPDATE = "UPDATE"
#     ASSIGN = "ASSIGN"
#     APPROVE = "APPROVE"
#     PUBLISH = "PUBLISH"
#     MANAGE = "MANAGE"


# class PermissionScope(StrEnum):
#     OWN = "OWN"
#     ASSIGNED_WARD = "ASSIGNED_WARD"
#     ASSIGNED_DEPARTMENT = "ASSIGNED_DEPARTMENT"
#     ASSIGNED_PROJECT = "ASSIGNED_PROJECT"
#     ALL = "ALL"


# class ModuleCode(StrEnum):
#     COMPLAINT = "COMPLAINT"
#     PROJECT = "PROJECT"
#     ANNOUNCEMENT = "ANNOUNCEMENT"
#     REEL = "REEL"
#     FEEDBACK = "FEEDBACK"
#     CLEANING = "CLEANING"
#     EMERGENCY = "EMERGENCY"
#     DIRECTORY = "DIRECTORY"
#     USER = "USER"
#     ROLE = "ROLE"
#     WARD = "WARD"
#     DEPARTMENT = "DEPARTMENT"
#     ANALYTICS = "ANALYTICS"
#     AUDIT = "AUDIT"
#     SETTINGS = "SETTINGS"
#     EVIDENCE = "EVIDENCE"
#     NOTIFICATION = "NOTIFICATION"


# class ComplaintStatus(StrEnum):
#     SUBMITTED = "SUBMITTED"
#     UNDER_REVIEW = "UNDER_REVIEW"
#     ASSIGNED = "ASSIGNED"
#     IN_PROGRESS = "IN_PROGRESS"
#     ON_HOLD = "ON_HOLD"
#     RESOLVED = "RESOLVED"
#     REOPENED = "REOPENED"
#     CLOSED = "CLOSED"
#     REJECTED = "REJECTED"


# class ComplaintCategory(StrEnum):
#     GARBAGE = "GARBAGE"
#     ROADS = "ROADS"
#     STREETLIGHTS = "STREETLIGHTS"
#     WATER_LEAKAGE = "WATER_LEAKAGE"
#     DRAINAGE = "DRAINAGE"
#     SANITATION = "SANITATION"
#     PUBLIC_PROPERTY = "PUBLIC_PROPERTY"
#     ELECTRICITY = "ELECTRICITY"
#     HEALTH = "HEALTH"
#     OTHER = "OTHER"


# class ProjectStatus(StrEnum):
#     PLANNED = "PLANNED"
#     APPROVED = "APPROVED"
#     IN_PROGRESS = "IN_PROGRESS"
#     DELAYED = "DELAYED"
#     COMPLETED = "COMPLETED"
#     CANCELLED = "CANCELLED"


# class AnnouncementStatus(StrEnum):
#     DRAFT = "DRAFT"
#     PUBLISHED = "PUBLISHED"
#     SCHEDULED = "SCHEDULED"
#     ARCHIVED = "ARCHIVED"


# class VerificationStatus(StrEnum):
#     VERIFIED = "VERIFIED"
#     SUSPICIOUS = "SUSPICIOUS"
#     NEEDS_REVIEW = "NEEDS_REVIEW"
#     UNVERIFIED = "UNVERIFIED"


# class EvidenceSource(StrEnum):
#     CAMERA_CAPTURE = "CAMERA_CAPTURE"
#     UPLOADED_FILE = "UPLOADED_FILE"


# class EmergencyAvailability(StrEnum):
#     AVAILABLE = "AVAILABLE"
#     BUSY = "BUSY"
#     OFFLINE = "OFFLINE"
#     UNKNOWN = "UNKNOWN"


# class CleaningStatus(StrEnum):
#     SCHEDULED = "SCHEDULED"
#     IN_PROGRESS = "IN_PROGRESS"
#     COMPLETED = "COMPLETED"
#     CANCELLED = "CANCELLED"



from enum import StrEnum


class RoleCode(StrEnum):
    CITIZEN = "CITIZEN"
    NAGAR_SEVAK = "NAGAR_SEVAK"
    OFFICER = "OFFICER"
    ENGINEER = "ENGINEER"
    CONTRACTOR = "CONTRACTOR"
    ADMIN = "ADMIN"


class PermissionAction(StrEnum):
    VIEW = "VIEW"
    CREATE = "CREATE"
    EDIT = "EDIT"
    DELETE = "DELETE"
    UPDATE = "UPDATE"
    ASSIGN = "ASSIGN"
    APPROVE = "APPROVE"
    PUBLISH = "PUBLISH"
    MANAGE = "MANAGE"


class PermissionScope(StrEnum):
    OWN = "OWN"
    ASSIGNED_WARD = "ASSIGNED_WARD"
    ASSIGNED_DEPARTMENT = "ASSIGNED_DEPARTMENT"
    ASSIGNED_PROJECT = "ASSIGNED_PROJECT"
    ALL = "ALL"


class ModuleCode(StrEnum):
    COMPLAINT = "COMPLAINT"
    PROJECT = "PROJECT"
    ANNOUNCEMENT = "ANNOUNCEMENT"
    REEL = "REEL"
    FEEDBACK = "FEEDBACK"
    CLEANING = "CLEANING"
    EMERGENCY = "EMERGENCY"
    DIRECTORY = "DIRECTORY"
    USER = "USER"
    ROLE = "ROLE"
    WARD = "WARD"
    DEPARTMENT = "DEPARTMENT"
    ANALYTICS = "ANALYTICS"
    AUDIT = "AUDIT"
    SETTINGS = "SETTINGS"
    EVIDENCE = "EVIDENCE"
    NOTIFICATION = "NOTIFICATION"


class ComplaintStatus(StrEnum):
    SUBMITTED = "SUBMITTED"
    UNDER_REVIEW = "UNDER_REVIEW"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    ON_HOLD = "ON_HOLD"
    RESOLVED = "RESOLVED"
    REOPENED = "REOPENED"
    CLOSED = "CLOSED"
    REJECTED = "REJECTED"


class ComplaintCategory(StrEnum):
    GARBAGE = "GARBAGE"
    ROADS = "ROADS"
    STREETLIGHTS = "STREETLIGHTS"
    WATER_LEAKAGE = "WATER_LEAKAGE"
    DRAINAGE = "DRAINAGE"
    SANITATION = "SANITATION"
    PUBLIC_PROPERTY = "PUBLIC_PROPERTY"
    ELECTRICITY = "ELECTRICITY"
    HEALTH = "HEALTH"
    OTHER = "OTHER"


class ProjectStatus(StrEnum):
    PLANNED = "PLANNED"
    APPROVED = "APPROVED"
    IN_PROGRESS = "IN_PROGRESS"
    DELAYED = "DELAYED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"


class AnnouncementStatus(StrEnum):
    DRAFT = "DRAFT"
    PUBLISHED = "PUBLISHED"
    SCHEDULED = "SCHEDULED"
    ARCHIVED = "ARCHIVED"


class VerificationStatus(StrEnum):
    VERIFIED = "VERIFIED"
    SUSPICIOUS = "SUSPICIOUS"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    UNVERIFIED = "UNVERIFIED"


class EvidenceSource(StrEnum):
    CAMERA_CAPTURE = "CAMERA_CAPTURE"
    UPLOADED_FILE = "UPLOADED_FILE"


class EvidenceRole(StrEnum):
    """What stage of the repair lifecycle this evidence file represents.

    GENERAL is used by non-pothole complaint categories (unchanged behaviour).
    BEFORE / AFTER are used by the pothole repair-verification flow.
    """

    GENERAL = "GENERAL"
    BEFORE = "BEFORE"
    AFTER = "AFTER"


class ComplaintSeverity(StrEnum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class RepairVerificationStatus(StrEnum):
    PENDING = "PENDING"
    VERIFIED = "VERIFIED"
    REVIEW_REQUIRED = "REVIEW_REQUIRED"
    FAILED = "FAILED"


class EmergencyAvailability(StrEnum):
    AVAILABLE = "AVAILABLE"
    BUSY = "BUSY"
    OFFLINE = "OFFLINE"
    UNKNOWN = "UNKNOWN"


class CleaningStatus(StrEnum):
    SCHEDULED = "SCHEDULED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
